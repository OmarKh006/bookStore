# BookStore API (TypeScript)

TypeScript / Node.js / Express 5 / MongoDB (Mongoose 9) port of the BookStore REST API.
Endpoints, validation rules, status codes and JSON shapes are unchanged from the JavaScript version, so the existing API reference still applies.

## Quick start

```bash
npm install
cp .env.example .env        # fill in MONGO_URI, JWT_SECRET, BASE_URL (+ SMTP_* for password reset)
npm run dev                 # tsx watch src/server.ts
```

Production:

```bash
npm run build               # tsc -> dist/
npm start                   # node dist/server.js
```

Seed data (guarded by `SEED_DB_NAME`):

```bash
npm run seed:import
npm run seed:delete
```

## Scripts

| Script                                      | Purpose                              |
| ------------------------------------------- | ------------------------------------ |
| `dev`                                       | Run with auto-reload (tsx)           |
| `build` / `start`                           | Compile to `dist/` and run it        |
| `typecheck`                                 | `tsc --noEmit` (src + tests)         |
| `test`, `test:watch`, `test:unit`, `test:integration`, `test:coverage` | See [TESTING.md](./TESTING.md) |
| `seed:import`, `seed:delete`                | Seeder                               |

## Project structure

```
src/
├── app.ts                 createApp(): middleware + routes + error handlers (no listen / no DB)
├── server.ts              Entry point: env check, DB connect, listen
├── seeder.ts, data.ts     Seeder (importData/deleteData are exported and tested) + sample data
├── config/                env.ts (required vars), connectToDB.ts
├── controllers/           authors, books, users (auth + users) + Joi validators + email service
├── middleware/            errorHandlers, hashPassword, rateLimiter, validateObjectId, verifyToken
├── models/                Author, Book, User (typed Mongoose models)
├── routes/                authors, books, auth, users, uploads
└── types/                 AuthPayload, HttpError, Express Request augmentation (req.user)
views/                     EJS pages for the password-reset flow
images/                    default.png + uploaded images (git-ignored)
tests/                     unit/, integration/, helpers/  (see TESTING.md)
```

## What changed vs. the JavaScript version

Behaviour-preserving refactors made so the code is testable:

- **`app.ts` / `server.ts` split.** `createApp()` no longer connects to MongoDB or listens; `server.ts` does that. Supertest uses `createApp()`.
- **Rate limiter is a factory** (`createLimiter(limit = 10)`), injected through `createApp({ rateLimitMax })`. Production default is still 10 per 15 min per IP.
- **Email transporter is created lazily** on first use instead of at import time, so env vars are read when needed and tests can mock it. (`import "dotenv/config"` moved to `server.ts`.)
- **`seeder.ts` exports `importData` / `deleteData` / `runSeeder`.** The CLI still works the same (`SEED_DB_NAME` guard included) but nothing runs at import time.
- **`UPLOAD_DIR` env var (optional)** overrides where uploads are written; defaults to `./images` as before.
- **`result._doc` → `toObject()`** when stripping `password` from register/login responses.
- **Models live in `src/models/*.model.ts`** (flattened one level; the folders had one file each).

One small hardening: `app.ts` sets `req.body ??= {}` after the body parsers. Express 5 leaves `req.body` undefined when a request has no body, which would otherwise make controllers read properties of `undefined`. Such requests now get the normal 400 validation error.

## Tooling notes

- ESM (`"type": "module"`, `module: NodeNext`) — relative imports keep the `.js` extension, same convention as the original project.
- `strict` + `noUncheckedIndexedAccess` are on.
- Node ≥ 20.11 (uses `import.meta.dirname` / `import.meta.filename`).
